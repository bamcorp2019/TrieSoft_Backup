// cpanel - site_templates/countdown_tech/assets/config.js.tt Copyright(c) 2016 cPanel, Inc.
//                                                          All rights Reserved.
// copyright@cpanel.net                                        http://cpanel.net
// This code is subject to the cPanel license. Unauthorized copying is prohibited

window.cpanel = {
    data: {
        email: "",
        logo: "Trie Software",
        social: [
            
            
            
            
            
            
        ]
    },
    style: {
        primary: "",
    },
    slides: [
        {
            type: 'countdown',
            backgroundImage: "",
            backgroundColor: "",
            color: "#ffffff",
            buttonText: "",
            buttonLink: "",
            endTime: '2020-06-13T04:30:00.000Z',
            content: "Want to Experience a New Software ?... Wait !\nWe are Coming Soon.........",
        }
    ]
};
